class Worker extends User {
    private double salary; // Зарплата

    // Метод для установки зарплаты
    public void setSalary(double salary) {
        this.salary = salary;
    }

    // Метод для получения зарплаты
    public double getSalary() {
        return salary;
    }
}
