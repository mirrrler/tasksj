class Student extends User {
    private double scholarship; // Стипендия
    private int course;         // Курс

    // Метод для установки стипендии
    public void setScholarship(double scholarship) {
        this.scholarship = scholarship;
    }

    // Метод для получения стипендии
    public double getScholarship() {
        return scholarship;
    }

    // Метод для установки курса
    public void setCourse(int course) {
        this.course = course;
    }

    // Метод для получения курса
    public int getCourse() {
        return course;
    }
}

