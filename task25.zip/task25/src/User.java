class User {
    protected String name; // Имя
    protected int age;     // Возраст

    // Метод для установки имени
    public void setName(String name) {
        this.name = name;
    }

    // Метод для получения имени
    public String getName() {
        return name;
    }

    // Метод для установки возраста
    public void setAge(int age) {
        this.age = age;
    }

    // Метод для получения возраста
    public int getAge() {
        return age;
    }
}

